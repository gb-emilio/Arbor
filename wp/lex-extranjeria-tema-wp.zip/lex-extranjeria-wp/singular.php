<?php get_header(); ?>
<main id="main" role="main" style="max-width:760px;margin:60px auto;padding:0 24px;min-height:60vh">
  <?php while(have_posts()):the_post(); ?>
  <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <span class="label"><?php the_category(', '); ?></span>
    <h1 style="margin:12px 0 24px"><?php the_title(); ?></h1>
    <?php if(has_post_thumbnail()): ?><div style="margin-bottom:28px"><?php the_post_thumbnail('large',['style'=>'width:100%;height:auto;filter:sepia(10%)']); ?></div><?php endif; ?>
    <div class="entry-content" style="font-size:1.05rem;line-height:1.8;color:var(--ink-soft)"><?php the_content(); ?></div>
  </article>
  <?php endwhile; ?>
</main>
<?php get_footer(); ?>
