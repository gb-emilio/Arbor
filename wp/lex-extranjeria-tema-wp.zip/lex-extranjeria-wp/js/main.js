/* Lex Extranjería — main.js */
(function () {
  'use strict';

  /* ── Menú móvil ──────────────────────────────────── */
  const toggle = document.getElementById('nav-toggle');
  const nav    = document.getElementById('main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open);
    });
    // Cierra al hacer clic en un enlace
    nav.querySelectorAll('a').forEach(a =>
      a.addEventListener('click', () => {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      })
    );
  }

  /* ── Reveal on scroll (IntersectionObserver) ─────── */
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('[data-reveal]').forEach(el => io.observe(el));
  } else {
    document.querySelectorAll('[data-reveal]').forEach(el => el.classList.add('on'));
  }

  /* ── Active nav link según sección visible ───────── */
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.main-nav a[href^="#"]');
  if (sections.length && navLinks.length) {
    const secObs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          navLinks.forEach(a => a.parentElement.classList.remove('active'));
          const link = document.querySelector(`.main-nav a[href="#${e.target.id}"]`);
          if (link) link.parentElement.classList.add('active');
        }
      });
    }, { rootMargin: '-40% 0px -50% 0px' });
    sections.forEach(s => secObs.observe(s));
  }

  /* ── Formulario de contacto (AJAX) ───────────────── */
  const form   = document.getElementById('contact-form');
  const msgEl  = document.getElementById('form-msg');
  if (form && msgEl && window.lexData) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('[type="submit"]');
      btn.disabled = true;
      btn.innerHTML = `<i class="ti ti-loader-2" style="animation:spin .8s linear infinite"></i>${lexData.sending}`;
      msgEl.className = 'form-msg';
      msgEl.textContent = '';

      const fd = new FormData(form);
      fd.append('action', 'lexext_contact');
      fd.append('nonce',  lexData.nonce);

      try {
        const res  = await fetch(lexData.ajaxUrl, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
          msgEl.className = 'form-msg success';
          msgEl.textContent = data.data.msg || lexData.ok;
          form.reset();
        } else {
          msgEl.className = 'form-msg error';
          msgEl.textContent = data.data?.msg || lexData.err;
        }
      } catch {
        msgEl.className = 'form-msg error';
        msgEl.textContent = lexData.err;
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="ti ti-send"></i>Enviar mensaje';
      }
    });
  }

  /* ── Smooth-scroll para anclas ───────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      const offset = 80;
      window.scrollTo({ top: target.getBoundingClientRect().top + scrollY - offset, behavior: 'smooth' });
    });
  });

  /* Keyframe spin para el botón de carga */
  const style = document.createElement('style');
  style.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
  document.head.appendChild(style);
})();
