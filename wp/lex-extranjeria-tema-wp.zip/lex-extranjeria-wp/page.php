<?php get_header(); ?>
<main id="main" role="main" style="max-width:860px;margin:60px auto;padding:0 24px;min-height:60vh">
  <?php while(have_posts()):the_post(); ?>
  <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <h1 style="margin-bottom:24px"><?php the_title(); ?></h1>
    <div class="entry-content" style="font-size:1.05rem;line-height:1.8;color:var(--ink-soft)"><?php the_content(); ?></div>
  </article>
  <?php endwhile; ?>
</main>
<?php get_footer(); ?>
