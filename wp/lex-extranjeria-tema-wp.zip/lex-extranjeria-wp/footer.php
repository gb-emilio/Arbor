<?php
$name   = lmod('lawyer_name',    'Dra. Elena Martínez');
$phone  = lmod('office_phone',   '+34 91 234 56 78');
$email  = lmod('office_email',   'info@lexextranjeria.es');
$addr   = lmod('office_address', 'Calle Serrano 45, 3ª · Madrid');
$icons  = ['linkedin'=>'ti-brand-linkedin','twitter'=>'ti-brand-twitter','instagram'=>'ti-brand-instagram','facebook'=>'ti-brand-facebook'];
?>

<footer id="site-footer" role="contentinfo">
  <div class="container">
    <div class="footer-top">

      <div class="footer-brand">
        <span class="logo-name"><?php echo $name; ?></span>
        <span class="logo-tag" style="font-family:var(--ff-ui);font-size:.6rem;letter-spacing:.2em;text-transform:uppercase;color:var(--gold);display:block;margin-top:3px"><?php echo lmod('lawyer_title','Abogada de Extranjería'); ?></span>
        <p>Despacho especializado en extranjería, inmigración y derecho migratorio. Más de <?php echo lmod('stat_years','15+'); ?> años de experiencia al servicio de nuestros clientes.</p>
        <?php if(!empty(array_filter(array_map(fn($n)=>get_theme_mod("social_{$n}",''),['linkedin','twitter','instagram','facebook'])))): ?>
        <div class="social-row" style="margin-top:16px">
          <?php foreach($icons as $net=>$icon):
            $url = get_theme_mod("social_{$net}",'');
            if($url): ?>
            <a href="<?php echo esc_url($url); ?>" class="soc" target="_blank" rel="noopener" aria-label="<?php echo ucfirst($net); ?>">
              <i class="ti <?php echo $icon; ?>"></i>
            </a>
          <?php endif; endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <div class="fc">
        <h4>Servicios</h4>
        <ul>
          <?php foreach(['Residencia y visados','Nacionalidad española','Reagrupación familiar','Autorización de trabajo','Recursos y sanciones','Arraigo social y laboral'] as $s): ?>
          <li><a href="#servicios"><?php echo $s; ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div class="fc">
        <h4>Despacho</h4>
        <ul>
          <li><a href="#nosotros">Sobre nosotros</a></li>
          <li><a href="#prensa">Prensa</a></li>
          <li><a href="#consulta">Consulta gratuita</a></li>
          <li><a href="#contacto">Contacto</a></li>
          <li><a href="<?php echo esc_url(get_privacy_policy_url()); ?>">Política de privacidad</a></li>
        </ul>
      </div>

      <div class="fc">
        <h4>Contacto</h4>
        <ul>
          <li><a href="tel:<?php echo preg_replace('/\s/','',$phone); ?>"><?php echo $phone; ?></a></li>
          <li><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></li>
          <li><span style="color:rgba(245,240,232,.45);font-size:.88rem"><?php echo $addr; ?></span></li>
          <li><span style="color:rgba(245,240,232,.45);font-size:.88rem"><?php echo lmod('office_hours','Lun–Vie 9:00–20:00'); ?></span></li>
        </ul>
      </div>

    </div><!-- .footer-top -->

    <div class="footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> <?php echo $name; ?> · Todos los derechos reservados</span>
      <div class="footer-legal">
        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>">Privacidad</a>
        <a href="#">Aviso legal</a>
        <a href="#">Cookies</a>
      </div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
