<?php
// Genera una imagen de previsualización del tema
header('Content-Type: image/svg+xml');
echo '<?xml version="1.0"?>';
?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="900" viewBox="0 0 1200 900">
  <rect width="1200" height="900" fill="#1A1208"/>
  <rect width="600" height="900" fill="#1A1208"/>
  <rect x="600" width="600" height="900" fill="#EDE6D6"/>
  <text x="80" y="200" font-family="Georgia,serif" font-size="72" font-style="italic" fill="#F5F0E8">Tu futuro en</text>
  <text x="80" y="300" font-family="Georgia,serif" font-size="72" font-style="italic" fill="#B8963E">España</text>
  <text x="80" y="380" font-family="Georgia,serif" font-size="40" fill="rgba(245,240,232,0.6)">Abogada de Extranjería</text>
  <rect x="80" y="440" width="200" height="3" fill="#B8963E"/>
  <rect x="0" y="0" width="1200" height="72" fill="rgba(245,240,232,0.95)"/>
  <text x="40" y="46" font-family="Georgia,serif" font-size="22" font-weight="700" fill="#1A1208">Dra. Elena Martínez</text>
  <text x="800" y="46" font-family="Arial,sans-serif" font-size="11" fill="#7A7060">INICIO · NOSOTROS · SERVICIOS · PRENSA · CONTACTO</text>
  <rect x="960" y="20" width="160" height="34" rx="4" fill="#B8963E"/>
  <text x="980" y="42" font-family="Arial,sans-serif" font-size="11" font-weight="600" fill="#fff">CONSULTA GRATUITA</text>
</svg>
