<?php get_header(); ?>
<main style="max-width:600px;margin:80px auto;padding:0 24px;text-align:center;min-height:60vh;display:flex;flex-direction:column;align-items:center;justify-content:center">
  <div style="font-family:var(--ff-display);font-size:120px;font-weight:700;color:var(--gold-pale);line-height:1">404</div>
  <h1 style="margin-bottom:16px">Página no encontrada</h1>
  <p style="color:var(--muted);margin-bottom:28px">La página que buscas no existe o ha sido movida.</p>
  <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary"><i class="ti ti-home"></i>Volver al inicio</a>
</main>
<?php get_footer(); ?>
