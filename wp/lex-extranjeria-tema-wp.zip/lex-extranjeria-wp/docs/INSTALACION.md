# Lex Extranjería — Guía de instalación

## Requisitos
- WordPress 6.0+
- PHP 8.0+
- Servidor web con soporte HTTPS

---

## 1. Instalar el tema

1. Comprime la carpeta `lex-extranjeria/` en un `.zip`
2. En WordPress: **Apariencia → Temas → Añadir nuevo → Subir tema**
3. Sube el `.zip` y activa el tema
4. Ignora el aviso de "tema padre" — es un tema independiente

---

## 2. Configurar los datos del despacho

Ve a **Apariencia → Personalizar → Lex Extranjería → Datos del despacho**:

| Campo | Descripción |
|---|---|
| Nombre de la abogada | Aparece en el header, footer y sección Nosotros |
| Título / especialidad | Subtítulo bajo el nombre |
| Nº de colegiada | Se muestra en la sección Nosotros |
| Teléfono | Enlazado como `tel:` en contacto y footer |
| Email | Destino del formulario de contacto |
| Dirección | Sección Contacto y Footer |
| Horario | Sección Contacto y Footer |
| Años experiencia | Estadística en Hero y badge Nosotros |
| Casos resueltos | Estadística en Hero |
| Tasa de éxito | Estadística en Hero y valores Nosotros |

---

## 3. Subir la foto de la abogada

Ve a **Lex Extranjería → Sección Inicio (Hero) → Foto hero**:
- Formato recomendado: JPEG o WebP, orientación vertical (retrato)
- Tamaño mínimo: 800×1000 px
- La misma foto se usa también en la sección Nosotros

---

## 4. Integrar la aplicación ArborQ

Ve a **Lex Extranjería → Consulta Gratuita (ArborQ)**:

1. Asegúrate de que tu instancia ArborQ está en funcionamiento
2. La URL debe apuntar a la ruta pública `/guia` de ArborQ:
   ```
   https://consulta.tudespacho.es/guia
   ```
3. Pega esa URL en el campo y guarda
4. La app se embebe en un `<iframe>` dentro de la sección "Consulta gratuita"

### Configurar CORS en ArborQ

Para que el iframe funcione, el backend ArborQ debe permitir el dominio de WordPress.
En `SecurityConfig.java`, añade el dominio de tu web:

```java
config.setAllowedOriginPatterns(List.of(
    "https://tudespacho.es",
    "https://www.tudespacho.es"
));
```

### Opción alternativa: enlace externo

Si prefieres abrir ArborQ en una pestaña nueva en lugar de un iframe,
modifica en `index.php` la sección `consulta` reemplazando el `<iframe>` por:

```html
<a href="TU_URL_ARBORQ" target="_blank" class="btn btn-primary">
  <i class="ti ti-external-link"></i>Iniciar consulta gratuita
</a>
```

---

## 5. Redes sociales

Ve a **Lex Extranjería → Redes sociales** y pega las URLs completas de cada perfil.
Los iconos aparecen en el footer. Solo se muestran los que tienen URL.

---

## 6. Logotipo personalizado

Si prefieres un logo gráfico en lugar del nombre en texto:
1. Ve a **Apariencia → Personalizar → Identidad del sitio → Logotipo**
2. Sube tu imagen (PNG transparente, máx. 220px de ancho recomendado)

---

## 7. Añadir artículos de prensa reales

Los artículos de prensa mostrados son de ejemplo. Para personalizarlos,
edita directamente el array `$articles` en `index.php` (línea ~130):

```php
$articles = [
  ['El País', 'Mar 2025', 'Título del artículo', 'Extracto breve…'],
  // añade más filas aquí
];
```

También puedes crear una Custom Post Type "Prensa" e integrarla — consulta el
apartado de extensiones en la documentación.

---

## 8. Formulario de contacto

El formulario usa AJAX nativo de WordPress (`wp_mail`).
Para mejorar la entregabilidad del email, instala un plugin SMTP como:
- **WP Mail SMTP** (gratuito)
- **FluentSMTP** (gratuito)

Y configura las credenciales de tu servidor de correo.

---

## Estructura de archivos

```
lex-extranjeria/
├── style.css          Estilos principales + cabecera del tema
├── functions.php      Setup, enqueue, customizer, AJAX
├── index.php          Página de inicio completa (todas las secciones)
├── header.php         Cabecera HTML + navegación
├── footer.php         Pie de página
├── page.php           Plantilla para páginas internas
├── singular.php       Plantilla para entradas del blog
├── 404.php            Página de error 404
└── js/
    └── main.js        Menú móvil, scroll-reveal, formulario AJAX
```
