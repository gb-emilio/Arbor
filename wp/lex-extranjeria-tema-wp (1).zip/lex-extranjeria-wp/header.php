<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header id="site-header" role="banner">
  <div class="header-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo" aria-label="<?php bloginfo('name'); ?>">
      <?php if(has_custom_logo()): the_custom_logo();
      else: ?>
        <span class="logo-name"><?php echo lmod('lawyer_name','Dra. Elena Martínez'); ?></span>
        <span class="logo-tag"><?php echo lmod('lawyer_title','Abogada de Extranjería'); ?></span>
      <?php endif; ?>
    </a>
    <nav class="main-nav" id="main-nav" aria-label="Menú principal">
      <ul>
        <li><a href="#inicio">Inicio</a></li>
        <li><a href="#nosotros">Nosotros</a></li>
        <li><a href="#servicios">Servicios</a></li>
        <li><a href="#prensa">Prensa</a></li>
        <li><a href="#contacto">Contacto</a></li>
        <li class="nav-cta"><a href="#consulta">Consulta gratuita</a></li>
      </ul>
    </nav>
    <button class="nav-toggle" id="nav-toggle" aria-controls="main-nav" aria-expanded="false" aria-label="Abrir menú">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>
