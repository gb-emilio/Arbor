<?php get_header(); ?>
<?php
$name     = lmod('lawyer_name',    'Dra. Elena Martínez');
$title    = lmod('lawyer_title',   'Abogada de Extranjería');
$years    = lmod('stat_years',     '15+');
$cases    = lmod('stat_cases',     '2.400+');
$rate     = lmod('stat_rate',      '96%');
$phone    = lmod('office_phone',   '+34 91 234 56 78');
$email    = lmod('office_email',   'info@lexextranjeria.es');
$address  = lmod('office_address', 'Calle Serrano 45, 3ª planta · Madrid');
$hours    = lmod('office_hours',   'Lun–Vie 9:00–20:00 · Sáb 10:00–14:00');
$hero_t   = get_theme_mod('hero_title','Tu futuro en España <em>comienza aquí</em>');
$hero_s   = lmod('hero_sub','Asesoramiento jurídico especializado en extranjería e inmigración. Más de 15 años ayudando a personas a construir su vida en España.');
$hero_img = get_theme_mod('hero_image','');
$arborq        = get_theme_mod('arborq_url','');
$arborq_img    = get_theme_mod('arborq_lawyer_img',  get_theme_mod('hero_image',''));
$arborq_name   = get_theme_mod('arborq_lawyer_name',  get_theme_mod('lawyer_name',''));
$arborq_ititle = get_theme_mod('arborq_lawyer_title', get_theme_mod('lawyer_title',''));
$soc = [];
foreach(['linkedin','twitter','instagram','facebook'] as $n) {
    $u = get_theme_mod("social_{$n}",'');
    if($u) $soc[$n] = $u;
}
$icons = ['linkedin'=>'ti-brand-linkedin','twitter'=>'ti-brand-twitter','instagram'=>'ti-brand-instagram','facebook'=>'ti-brand-facebook'];
?>

<!-- ══════════════════════════════════ INICIO / HERO ══ -->
<section id="inicio" aria-label="Inicio">
<div class="hero">

  <div class="hero-left">
    <p class="hero-eyebrow">Despacho especializado · Madrid</p>
    <h1><?php echo wp_kses_post($hero_t); ?></h1>
    <p class="hero-desc"><?php echo esc_html($hero_s); ?></p>
    <div class="hero-actions">
      <a href="#consulta" class="btn btn-primary"><i class="ti ti-message-question"></i>Consulta gratuita</a>
      <a href="#servicios" class="btn btn-outline"><i class="ti ti-briefcase"></i>Nuestros servicios</a>
    </div>
    <div class="hero-trust">
      <div class="hero-trust-item"><span class="ht-num"><?php echo $years; ?></span><span class="ht-lbl">Años de experiencia</span></div>
      <div class="hero-trust-item"><span class="ht-num"><?php echo $cases; ?></span><span class="ht-lbl">Casos resueltos</span></div>
      <div class="hero-trust-item"><span class="ht-num"><?php echo $rate; ?></span><span class="ht-lbl">Tasa de éxito</span></div>
    </div>
  </div>

  <div class="hero-right">
    <?php if($hero_img): ?>
      <img src="<?php echo esc_url($hero_img); ?>" alt="<?php echo esc_attr($name); ?>" loading="eager" fetchpriority="high">
    <?php else: ?>
      <div class="hero-placeholder">LEX</div>
    <?php endif; ?>
  </div>

</div>
</section>

<!-- ══════════════════════════════════ SERVICIOS ══ -->
<section id="servicios" class="section" aria-label="Servicios">
<div class="container">
  <div class="section-head" data-reveal>
    <span class="label">Lo que hacemos</span>
    <h2>Servicios jurídicos especializados</h2>
    <span class="gold-rule"></span>
    <p class="sub">Asesoramiento integral en todos los procedimientos de extranjería e inmigración en España.</p>
  </div>
  <div class="services-grid">
    <?php
    $services = [
      ['ti-passport','Residencia y visados','Tramitación de permisos de residencia temporal, larga duración, reagrupación familiar y visados de todo tipo.'],
      ['ti-star','Nacionalidad española','Procedimientos de adquisición de nacionalidad por residencia, arraigo, matrimonio y carta de naturaleza.'],
      ['ti-users','Reagrupación familiar','Reunificación de cónyuge, hijos y ascendientes. Tramitación completa y seguimiento del expediente.'],
      ['ti-building-store','Autorización trabajo','Permisos de trabajo por cuenta ajena, propia, y modificaciones de residencia y trabajo.'],
      ['ti-alert-triangle','Recursos y sanciones','Recursos contra resoluciones desfavorables, denegaciones y expedientes sancionadores.'],
      ['ti-home','Arraigo social y laboral','Regularización de situación irregular mediante arraigo laboral, social y familiar.'],
    ];
    foreach($services as [$icon,$heading,$desc]):
    ?>
    <div class="svc" data-reveal>
      <div class="svc-icon"><i class="ti <?php echo $icon; ?>"></i></div>
      <h3><?php echo $heading; ?></h3>
      <p><?php echo $desc; ?></p>
      <a href="#contacto" class="svc-link">Consultar</a>
    </div>
    <?php endforeach; ?>
  </div>
</div>
</section>

<!-- ══════════════════════════════════ NOSOTROS ══ -->
<section id="nosotros" class="section section-toned" aria-label="Nosotros">
<div class="container">
  <div class="about-grid">

    <div class="about-img" data-reveal>
      <?php if($hero_img): ?>
        <img src="<?php echo esc_url($hero_img); ?>" alt="<?php echo esc_attr($name); ?>">
      <?php else: ?>
        <div style="width:100%;aspect-ratio:4/5;background:linear-gradient(160deg,var(--cream-dark),var(--gold-pale));display:flex;align-items:center;justify-content:center;font-family:var(--ff-display);font-size:80px;color:rgba(184,150,62,.15);">⚖</div>
      <?php endif; ?>
      <div class="about-img-frame" aria-hidden="true"></div>
      <div class="about-badge"><strong><?php echo $years; ?></strong><span>años de experiencia</span></div>
    </div>

    <div class="about-content" data-reveal data-delay="2">
      <span class="label">Sobre nosotros</span>
      <h2>Un despacho comprometido con tu caso</h2>
      <span class="gold-rule"></span>
      <p><?php echo esc_html($name); ?>, <?php echo esc_html($title); ?>, lidera un equipo de profesionales con amplia experiencia en derecho migratorio y extranjería. Nuestro enfoque es siempre personalizado: cada caso merece atención individual y una estrategia adaptada a su situación específica.</p>
      <p>Colegiada nº <?php echo lmod('lawyer_ncol','28.456 ICAM'); ?>. Colaboramos con organizaciones de derechos humanos y ofrecemos tarifas adaptadas a cada situación económica.</p>
      <div class="about-values">
        <div class="aval"><h4>Proximidad</h4><p>Atención personal, sin intermediarios ni burocracia innecesaria.</p></div>
        <div class="aval"><h4>Transparencia</h4><p>Presupuesto cerrado desde el primer momento, sin sorpresas.</p></div>
        <div class="aval"><h4>Eficacia</h4><p><?php echo $rate; ?> de tasa de éxito en los últimos 5 años.</p></div>
        <div class="aval"><h4>Compromiso</h4><p>Seguimiento activo de cada expediente hasta su resolución.</p></div>
      </div>
    </div>
  </div>
</div>
</section>

<!-- ══════════════════════════════════ PRENSA ══ -->
<section id="prensa" class="section section-dark" aria-label="Prensa">
<div class="container">
  <div class="section-head" data-reveal>
    <span class="label" style="color:var(--gold)">Apariciones en medios</span>
    <h2 style="color:var(--cream)">El despacho en la prensa</h2>
    <span class="gold-rule"></span>
  </div>

  <div class="press-logos" data-reveal>
    <?php foreach(['El País','El Mundo','La Vanguardia','Expansión','El Confidencial','Cinco Días'] as $m): ?>
    <span class="press-logo-item"><?php echo $m; ?></span>
    <?php endforeach; ?>
  </div>

  <div class="press-grid">
    <?php
    $articles = [
      ['El País','Mar 2025','La abogada que ha ayudado a más de 2.000 inmigrantes a obtener la residencia','Un reportaje sobre el trabajo de ' . $name . ' y el impacto de la nueva ley de extranjería en los procesos de regularización.'],
      ['Expansión','Ene 2025','Extranjería: ¿qué cambia con la reforma del Reglamento de Extranjería?','Análisis jurídico sobre las novedades legislativas y su impacto en los trámites de residencia y trabajo.'],
      ['La Vanguardia','Nov 2024','Cómo conseguir la nacionalidad española en 2025: pasos y requisitos','Guía práctica con el asesoramiento de especialistas en derecho migratorio sobre el proceso de nacionalización.'],
    ];
    foreach($articles as [$source,$date,$heading,$excerpt]):
    ?>
    <div class="press-card" data-reveal>
      <div class="press-meta">
        <span class="press-source"><?php echo $source; ?></span>
        <span class="press-sep"></span>
        <span class="press-date"><?php echo $date; ?></span>
      </div>
      <h3><?php echo $heading; ?></h3>
      <p><?php echo $excerpt; ?></p>
      <a href="#" class="press-read">Leer artículo →</a>
    </div>
    <?php endforeach; ?>
  </div>
</div>
</section>

<!-- ══════════════════════════════════ CONSULTA GRATUITA ══ -->
<section id="consulta" class="section section-toned" aria-label="Consulta gratuita">
<div class="container consulta-wrap">

  <div class="consulta-intro" data-reveal>
    <div>
      <span class="label">Consulta gratuita</span>
      <h2>Resuelve tus dudas paso a paso</h2>
      <span class="gold-rule"></span>
      <p style="color:var(--muted);font-size:1rem;line-height:1.75">Nuestra guía interactiva analiza tu situación y te indica exactamente qué trámite necesitas, qué documentación debes preparar y cuáles son tus opciones legales — sin coste alguno.</p>
    </div>
    <div class="consulta-steps">
      <?php
      $steps = [
        ['Responde las preguntas','El sistema te guía con preguntas sencillas sobre tu situación actual.'],
        ['Identifica tu caso','La guía detecta cuál es el procedimiento adecuado para ti.'],
        ['Obtén tu informe','Descarga un documento PDF con los pasos y documentos necesarios.'],
        ['Contacta con nosotros','Si necesitas representación, estamos a un clic de distancia.'],
      ];
      foreach($steps as $i=>[$t,$d]):
      ?>
      <div class="c-step" data-reveal data-delay="<?php echo $i+1; ?>">
        <div class="c-step-n"><?php echo $i+1; ?></div>
        <div class="c-step-t"><h4><?php echo $t; ?></h4><p><?php echo $d; ?></p></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Frame ArborQ — sin barra decorativa, altura automática vía postMessage -->
  <div class="arborq-wrap" data-reveal>
    <?php if($arborq):
      // Construir URL con parámetros para la foto y nombre de la abogada
      $arborq_src = add_query_arg([
        'img'   => rawurlencode($arborq_img),
        'name'  => rawurlencode($arborq_name),
        'title' => rawurlencode($arborq_ititle),
      ], $arborq);
    ?>
      <iframe
        id="arborq-iframe"
        src="<?php echo esc_url($arborq_src); ?>"
        title="Consulta gratuita de extranjería"
        loading="lazy"
        allow="payment"
        scrolling="no"
        style="overflow:hidden;width:100%;border:none;display:block;min-height:480px"
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox">
      </iframe>
      <script>
      (function(){
        window.addEventListener('message', function(e){
          if(e.data && e.data.type === 'arborq-height'){
            var f = document.getElementById('arborq-iframe');
            if(f) f.style.height = (e.data.height + 24) + 'px';
          }
        });
      })();
      </script>
    <?php else: ?>
      <div class="arborq-setup">
        <div class="arborq-setup-icon"><i class="ti ti-settings"></i></div>
        <h3>Configura la consulta interactiva</h3>
        <p>Ve a <strong>Apariencia → Personalizar → Lex Extranjería → Consulta Gratuita</strong> y pega la URL de tu instancia ArborQ.</p>
        <p>URL de ejemplo: <code>https://consulta.tudespacho.es/guia</code></p>
        <a href="<?php echo esc_url(admin_url('customize.php?autofocus[section]=lexext_arborq')); ?>" class="btn btn-primary" style="margin-top:8px">
          <i class="ti ti-settings"></i>Configurar ahora
        </a>
      </div>
    <?php endif; ?>
  </div>

</div>
</section>

<!-- ══════════════════════════════════ CONTACTO ══ -->
<section id="contacto" class="section" aria-label="Contacto">
<div class="container">
  <div class="section-head" data-reveal>
    <span class="label">Contáctanos</span>
    <h2>Hablemos de tu caso</h2>
    <span class="gold-rule"></span>
  </div>
  <div class="contact-grid">

    <div data-reveal>
      <div class="contact-item">
        <div class="citem-icon"><i class="ti ti-phone"></i></div>
        <div class="citem-text"><h4>Teléfono</h4><p><a href="tel:<?php echo preg_replace('/\s/','',$phone); ?>"><?php echo $phone; ?></a></p></div>
      </div>
      <div class="contact-item">
        <div class="citem-icon"><i class="ti ti-mail"></i></div>
        <div class="citem-text"><h4>Email</h4><p><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></p></div>
      </div>
      <div class="contact-item">
        <div class="citem-icon"><i class="ti ti-map-pin"></i></div>
        <div class="citem-text"><h4>Dirección</h4><p><?php echo $address; ?></p></div>
      </div>
      <div class="contact-item">
        <div class="citem-icon"><i class="ti ti-clock"></i></div>
        <div class="citem-text"><h4>Horario</h4><p><?php echo $hours; ?></p></div>
      </div>
    </div>

    <div class="contact-form" data-reveal data-delay="2">
      <h3>Envíanos un mensaje</h3>
      <form id="contact-form" novalidate>
        <?php wp_nonce_field('lexext_nonce','_wpnonce'); ?>
        <div class="form-row">
          <div class="fg"><label for="cf-name">Nombre *</label><input id="cf-name" name="name" type="text" placeholder="Tu nombre completo" required></div>
          <div class="fg"><label for="cf-email">Email *</label><input id="cf-email" name="email" type="email" placeholder="correo@ejemplo.com" required></div>
        </div>
        <div class="form-row">
          <div class="fg"><label for="cf-phone">Teléfono</label><input id="cf-phone" name="phone" type="tel" placeholder="+34 600 000 000"></div>
          <div class="fg"><label for="cf-subject">Asunto *</label>
            <select id="cf-subject" name="subject">
              <option value="">Selecciona un asunto…</option>
              <option>Residencia y permisos</option>
              <option>Nacionalidad española</option>
              <option>Reagrupación familiar</option>
              <option>Autorización de trabajo</option>
              <option>Recursos / sanciones</option>
              <option>Arraigo social o laboral</option>
              <option>Otro asunto</option>
            </select>
          </div>
        </div>
        <div class="fg"><label for="cf-msg">Mensaje *</label><textarea id="cf-msg" name="message" placeholder="Cuéntanos brevemente tu situación…" required></textarea></div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center"><i class="ti ti-send"></i>Enviar mensaje</button>
        <div class="form-msg" id="form-msg"></div>
      </form>
    </div>

  </div>
</div>
</section>

<?php get_footer(); ?>
