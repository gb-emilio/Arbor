<?php
/**
 * Lex Extranjería — functions.php
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LEXEXT_VER', '1.0.0' );
define( 'LEXEXT_URI', get_template_directory_uri() );

/* ── Setup ───────────────────────────────────────────── */
function lexext_setup() {
    load_theme_textdomain( 'lex-extranjeria', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', ['search-form','comment-form','comment-list','gallery','caption','script','style'] );
    add_theme_support( 'custom-logo', ['height'=>80,'width'=>220,'flex-height'=>true,'flex-width'=>true] );
    add_theme_support( 'responsive-embeds' );
    register_nav_menus([
        'primary' => 'Menú principal',
        'footer'  => 'Menú pie de página',
    ]);
}
add_action( 'after_setup_theme', 'lexext_setup' );

/* ── Enqueue ─────────────────────────────────────────── */
function lexext_scripts() {
    wp_enqueue_style( 'lexext-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400;1,700&family=Cormorant+Garamond:ital,wght@0,400;0,500;1,400&family=DM+Sans:wght@400;500&display=swap',
        [], null );
    wp_enqueue_style( 'tabler',
        'https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.4.0/dist/tabler-icons.min.css',
        [], '3.4.0' );
    wp_enqueue_style( 'lexext-style', get_stylesheet_uri(), ['lexext-fonts','tabler'], LEXEXT_VER );
    wp_enqueue_script( 'lexext-main', LEXEXT_URI . '/js/main.js', [], LEXEXT_VER, true );
    wp_localize_script( 'lexext-main', 'lexData', [
        'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
        'nonce'     => wp_create_nonce( 'lexext_nonce' ),
        'arborqUrl' => esc_url( get_theme_mod( 'arborq_url', '' ) ),
        'sending'   => __( 'Enviando…', 'lex-extranjeria' ),
        'ok'        => __( 'Mensaje enviado. Le contactaremos en 24 horas.', 'lex-extranjeria' ),
        'err'       => __( 'Error al enviar. Por favor, contacte por teléfono.', 'lex-extranjeria' ),
    ]);
}
add_action( 'wp_enqueue_scripts', 'lexext_scripts' );

/* ── Customizer ──────────────────────────────────────── */
function lexext_customize( $c ) {
    $c->add_panel('lexext', ['title'=>'Lex Extranjería','priority'=>30]);

    /* Despacho */
    $c->add_section('lexext_office',['title'=>'Datos del despacho','panel'=>'lexext']);
    $fields = [
        'lawyer_name'    => ['Nombre de la abogada',    'Dra. Elena Martínez'],
        'lawyer_title'   => ['Título / especialidad',   'Abogada de Extranjería'],
        'lawyer_ncol'    => ['Nº de colegiada',         '28.456 ICAM'],
        'office_phone'   => ['Teléfono',                '+34 91 234 56 78'],
        'office_email'   => ['Email',                   'info@lexextranjeria.es'],
        'office_address' => ['Dirección',               'Calle Serrano 45, 3ª planta · Madrid'],
        'office_hours'   => ['Horario',                 'Lun–Vie 9:00–20:00 · Sáb 10:00–14:00'],
        'stat_years'     => ['Años experiencia',        '15+'],
        'stat_cases'     => ['Casos resueltos',         '2.400+'],
        'stat_rate'      => ['Tasa de éxito',           '96%'],
    ];
    foreach ( $fields as $k => [$label,$default] ) {
        $c->add_setting($k,['default'=>$default,'sanitize_callback'=>'sanitize_text_field','transport'=>'postMessage']);
        $c->add_control($k,['label'=>$label,'section'=>'lexext_office','type'=>'text']);
    }

    /* Hero */
    $c->add_section('lexext_hero',['title'=>'Sección Inicio (Hero)','panel'=>'lexext']);
    $c->add_setting('hero_title',['default'=>'Tu futuro en España <em>comienza aquí</em>','sanitize_callback'=>'wp_kses_post']);
    $c->add_setting('hero_sub',['default'=>'Asesoramiento jurídico especializado en extranjería e inmigración. Más de 15 años ayudando a personas a construir su vida en España.','sanitize_callback'=>'sanitize_textarea_field']);
    $c->add_setting('hero_image',['default'=>'','sanitize_callback'=>'esc_url_raw']);
    $c->add_control('hero_title',['label'=>'Título hero (admite <em>)','section'=>'lexext_hero','type'=>'textarea']);
    $c->add_control('hero_sub',['label'=>'Subtítulo','section'=>'lexext_hero','type'=>'textarea']);
    $c->add_control(new WP_Customize_Image_Control($c,'hero_image',['label'=>'Foto hero','section'=>'lexext_hero']));

    /* ArborQ */
    $c->add_section('lexext_arborq',['title'=>'Consulta Gratuita — ArborQ','panel'=>'lexext']);
    $c->add_setting('arborq_url',['default'=>'','sanitize_callback'=>'esc_url_raw']);
    $c->add_control('arborq_url',['label'=>'URL de tu instancia ArborQ','description'=>'Ej: https://consulta.tudespacho.es/guia — Deja vacío para mostrar las instrucciones de configuración.','section'=>'lexext_arborq','type'=>'url']);

    /* Redes sociales */
    $c->add_section('lexext_social',['title'=>'Redes sociales','panel'=>'lexext']);
    foreach(['linkedin','twitter','instagram','facebook'] as $net) {
        $c->add_setting("social_{$net}",['default'=>'','sanitize_callback'=>'esc_url_raw']);
        $c->add_control("social_{$net}",['label'=>ucfirst($net),'section'=>'lexext_social','type'=>'url']);
    }
}
add_action( 'customize_register', 'lexext_customize' );

/* ── Widgets ─────────────────────────────────────────── */
add_action( 'widgets_init', function() {
    register_sidebar(['name'=>'Sidebar Blog','id'=>'sidebar-1',
        'before_widget'=>'<div class="widget %2$s">','after_widget'=>'</div>',
        'before_title'=>'<h4 class="widget-title">','after_title'=>'</h4>']);
});

/* ── AJAX contacto ───────────────────────────────────── */
function lexext_contact() {
    check_ajax_referer( 'lexext_nonce', 'nonce' );
    $name    = sanitize_text_field( $_POST['name']    ?? '' );
    $email   = sanitize_email(      $_POST['email']   ?? '' );
    $phone   = sanitize_text_field( $_POST['phone']   ?? '' );
    $subject = sanitize_text_field( $_POST['subject'] ?? '' );
    $msg     = sanitize_textarea_field( $_POST['message'] ?? '' );
    if ( empty($name) || empty($email) || empty($msg) || ! is_email($email) ) {
        wp_send_json_error(['msg'=>'Completa todos los campos obligatorios.']);
    }
    $to = get_theme_mod('office_email', get_option('admin_email'));
    $sent = wp_mail(
        $to,
        "[Lex Extranjería] $subject",
        "Nombre: $name\nEmail: $email\nTeléfono: $phone\nAsunto: $subject\n\n$msg",
        ["Reply-To: $name <$email>","Content-Type: text/plain; charset=UTF-8"]
    );
    $sent
        ? wp_send_json_success(['msg'=>'Mensaje enviado. Le contactaremos en 24 horas.'])
        : wp_send_json_error(['msg'=>'Error al enviar. Contacte por teléfono.']);
}
add_action('wp_ajax_lexext_contact',       'lexext_contact');
add_action('wp_ajax_nopriv_lexext_contact','lexext_contact');

/* ── Helper ──────────────────────────────────────────── */
function lmod( $key, $fallback = '' ) {
    return esc_html( get_theme_mod( $key, $fallback ) );
}
